#define NULL ((void *)0)
